#pragma once

#include "pch.h"
#include "Layer.h"
#include <glm/glm.hpp>

#include "Actor/GameObject.h"
#include "Renderer/Descriptor.h"
#include "Renderer/Device.h"
#include "Renderer/Renderer.h"
#include "Renderer/Window.h"

struct Vertex;

struct GLFWwindow;

struct AppSpec
{
	std::string Name = "GenX Vulkan Engine";
	uint32_t Width = 2560;
	uint32_t Height = 1440;
};

struct UniformBufferObject
{
	glm::mat4 Model;
	glm::mat4 View;
	glm::mat4 Projection;
};

class Application
{
private:
	struct SwapChainProperties
	{
		VkSurfaceCapabilitiesKHR Capabilities;
		std::vector<VkSurfaceFormatKHR> Formats;
		std::vector<VkPresentModeKHR> PresentModes;

		[[nodiscard]] bool IsValid() const
		{
			return !Formats.empty() && !PresentModes.empty();
		}
	};
	
public:
	Application(AppSpec spec = AppSpec());
	~Application();

	static Application& Get();

	void Run();
	void SetMenubarCallback(const std::function<void()>& menubarCallback) { m_MenubarCallback = menubarCallback; }
		
	template<typename T>
	void PushLayer()
	{
		static_assert(std::is_base_of_v<Layer, T>, "Pushed type is not subclass of Layer!");
		m_LayerStack.emplace_back(std::make_shared<T>())->OnAttach();
	}

	void PushLayer(const std::shared_ptr<Layer>& layer)
	{
		m_LayerStack.emplace_back(layer); layer->OnAttach();
	}

	void Close();
	static float GetTime();
	GLFWwindow* GetWindowHandle() const { return m_Window.GetWindow(); }

private:
	
	void Init();
	bool InitVulkan();
	void Shutdown();

	void InitImgui();
	void CleanupImGui() const;
	void CreateImGuiDescriptorPool();

	void loadGameObjects();
	
private:	
	AppSpec m_Spec;
	bool m_Running = false;

	float m_TimeStep = 0.0f;
	float m_FrameTime = 0.0f;
	float m_LastFrameTime = 0.0f;

	static constexpr int MAX_FRAMES_IN_FLIGHT = 2;
	
	std::vector<std::shared_ptr<Layer>> m_LayerStack;
	std::function<void()> m_MenubarCallback;
	
	/* --------------------------------------------------------------------*/

	Window m_Window {m_Spec.Width, m_Spec.Height, m_Spec.Name};
	Device m_Device {m_Window};
	Renderer m_Renderer {m_Window, m_Device};
	
	// note: order of declarations matters
	std::unique_ptr<DescriptorPool> globalPool{};
	GameObject::Map gameObjects;
	
	VkDescriptorPool m_ImGuiDescriptorPool = VK_NULL_HANDLE;
};

// Implemented by CLIENT
Application* CreateApplication(int argc, char** argv);
