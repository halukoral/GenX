#pragma once

class Shader
{
public:
	
};
