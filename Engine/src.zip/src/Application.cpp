#include "Application.h"
#include "Core.h"
#include "Vertex.h"

#include <GLFW/glfw3.h>
#include <vulkan/vulkan.h>
#include <spdlog/spdlog.h>

#define GLM_FORCE_RADIANS
#define GLM_FORCE_DEPTH_ZERO_TO_ONE
#include <glm/glm.hpp>
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/hash.hpp>
#include <glm/gtc/constants.hpp>

#include <imgui.h>
#include <imgui_impl_glfw.h>
#include <imgui_impl_vulkan.h>

#include "Renderer/movement.h"
#include "Renderer/PointLightSystem.h"
#include "Renderer/RenderSystem.h"

extern bool g_ApplicationRunning;
static Application* s_Instance = nullptr;

static ImGui_ImplVulkanH_Window g_MainWindowData;
static uint32_t                 g_MinImageCount = 2;

namespace std
{
	template<> struct hash<Vertex>
	{
		size_t operator()(Vertex const& vertex) const
		{
			return ((hash<glm::vec3>()(vertex.Position) ^ (hash<glm::vec2>()(vertex.TextCoord) << 1)));
		}
	};
}

void check_vk_result(VkResult err)
{
	if (err == 0)
		return;
	fprintf(stderr, "[vulkan] Error: VkResult = %d\n", err);
	if (err < 0)
		abort();
}

struct SimplePushConstantData
{
	glm::mat2 transform{1.f};
	glm::vec2 offset;
	alignas(16) glm::vec3 color;
};

Application::Application(AppSpec spec) : m_Spec(std::move(spec))
{
	s_Instance = this;
	Init();
}

Application::~Application()
{
	Shutdown();
	s_Instance = nullptr;
}

Application& Application::Get()
{
	return *s_Instance;
}

void Application::Init()
{	
	// Setup Vulkan
	if (!glfwVulkanSupported())
	{
		spdlog::error("GLFW: Vulkan not supported!");
		return;
	}

	if (!InitVulkan())
	{
		spdlog::error("Failed to initialize Vulkan!");
		return;
	}

	//InitImgui();
}

bool Application::InitVulkan()
{
	// Order matters
	m_Device.Initialize();
	m_Renderer.Initialize();

	globalPool =
	DescriptorPool::Builder(m_Device)
		.setMaxSets(SwapChain::MAX_FRAMES_IN_FLIGHT)
		.addPoolSize(VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, SwapChain::MAX_FRAMES_IN_FLIGHT)
		.build();
	loadGameObjects();
	
	loadGameObjects();
	return true;
}

void Application::InitImgui()
{
	CreateImGuiDescriptorPool();
	
	// Setup Dear ImGui context
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO(); (void)io;
	io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;     // Enable Keyboard Controls
	io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;      // Enable Gamepad Controls
	io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;

	ImGui::StyleColorsDark();
	ImGui_ImplVulkanH_Window* wd = &g_MainWindowData;
	
	// Setup Platform/Renderer backends
	ImGui_ImplGlfw_InitForVulkan(m_Window.GetWindow(), true);
	ImGui_ImplVulkan_InitInfo init_info = {};
	init_info.Instance = m_Device.GetInstance();
	init_info.PhysicalDevice = m_Device.GetPhysicalDevice();
	init_info.Device = m_Device.GetLogicalDevice();
	init_info.QueueFamily = m_Device.FindQueueFamilies(m_Device.GetPhysicalDevice()).GraphicsFamily.value();
	init_info.Queue = m_Device.GetGraphicsQueue();
	//init_info.PipelineCache = YOUR_PIPELINE_CACHE;
	init_info.DescriptorPool = m_ImGuiDescriptorPool;
	init_info.Subpass = 0;
	init_info.RenderPass = m_Renderer.getSwapChainRenderPass();
	init_info.MinImageCount = 2;
	init_info.ImageCount = 2;
	init_info.MSAASamples = VK_SAMPLE_COUNT_1_BIT;
	init_info.Allocator = nullptr;
	init_info.CheckVkResultFn = check_vk_result;
	ImGui_ImplVulkan_Init(&init_info);	
}

void Application::CleanupImGui() const
{
	vkDeviceWaitIdle(m_Device.GetLogicalDevice());
	ImGui_ImplVulkan_Shutdown();
	ImGui_ImplGlfw_Shutdown();
	ImGui::DestroyContext();
	vkDestroyDescriptorPool(m_Device.GetLogicalDevice(), m_ImGuiDescriptorPool, nullptr);
}

void Application::Shutdown()
{
	for (const auto& layer : m_LayerStack)
		layer->OnDetach();

	m_LayerStack.clear();

	//CleanupImGui();
	
	g_ApplicationRunning = false;
}

void Application::Run()
{
	m_Running = true;

	std::vector<std::unique_ptr<Buffer>> uboBuffers(SwapChain::MAX_FRAMES_IN_FLIGHT);
	for (int i = 0; i < uboBuffers.size(); i++) {
		uboBuffers[i] = std::make_unique<Buffer>(
			m_Device,
			sizeof(GlobalUbo),
			1,
			VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
			VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT);
		uboBuffers[i]->Map();
	}

	auto globalSetLayout =
	DescriptorSetLayout::Builder(m_Device)
		.addBinding(0, VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, VK_SHADER_STAGE_ALL_GRAPHICS)
		.build();
	
	std::vector<VkDescriptorSet> globalDescriptorSets(SwapChain::MAX_FRAMES_IN_FLIGHT);
	for (int i = 0; i < globalDescriptorSets.size(); i++) {
		auto bufferInfo = uboBuffers[i]->DescriptorInfo();
		DescriptorWriter(*globalSetLayout, *globalPool)
			.writeBuffer(0, &bufferInfo)
			.build(globalDescriptorSets[i]);
	}

	RenderSystem simpleRenderSystem{
		m_Device,
		m_Renderer.getSwapChainRenderPass(),
		globalSetLayout->getDescriptorSetLayout()};
	PointLightSystem pointLightSystem{
		m_Device,
		m_Renderer.getSwapChainRenderPass(),
		globalSetLayout->getDescriptorSetLayout()};

	Camera camera{};

	auto viewerObject = GameObject::createGameObject();
	viewerObject.transform.translation.z = -2.5f;
	KeyboardMovementController cameraController{};
	
	// Main loop
	while (!glfwWindowShouldClose(m_Window.GetWindow()) && m_Running)
	{
		glfwPollEvents();
		
		for (const auto& layer : m_LayerStack)
			layer->OnUpdate(m_TimeStep);

		////////////////////////////////////

		cameraController.moveInPlaneXZ(m_Window.GetWindow(), m_FrameTime, viewerObject);
		camera.setViewYXZ(viewerObject.transform.translation, viewerObject.transform.rotation);

		float aspect = m_Renderer.getAspectRatio();
		camera.setPerspectiveProjection(glm::radians(50.f), aspect, 0.1f, 100.f);
		
		////////////////////////////////////
		// Render
		if (auto commandBuffer = m_Renderer.beginFrame()) {
			int frameIndex = m_Renderer.getFrameIndex();
			FrameInfo frameInfo{
				frameIndex,
				m_FrameTime,
				commandBuffer,
				camera,
				globalDescriptorSets[frameIndex],
				gameObjects};

			// update
			GlobalUbo ubo{};
			ubo.projection = camera.getProjection();
			ubo.view = camera.getView();
			ubo.inverseView = camera.getInverseView();
			pointLightSystem.update(frameInfo, ubo);
			uboBuffers[frameIndex]->WriteToBuffer(&ubo);
			uboBuffers[frameIndex]->Flush();

			// render
			m_Renderer.beginSwapChainRenderPass(commandBuffer);

			// order here matters
			simpleRenderSystem.renderGameObjects(frameInfo);
			pointLightSystem.render(frameInfo);

			m_Renderer.endSwapChainRenderPass(commandBuffer);
			m_Renderer.endFrame();
		}
		////////////////////////////////////

		// Start the Dear ImGui frame
		// ImGui_ImplVulkan_NewFrame();
		// ImGui_ImplGlfw_NewFrame();
		// ImGui::NewFrame();
		//
		// ImGui::ShowDemoWindow();
		//
		// ImGui::Render();
		// ImGui_ImplVulkan_RenderDrawData(ImGui::GetDrawData(), m_CommandBuffers[m_SwapChain.GetCurrentFrame()]);
		
		const float time = GetTime();
		m_FrameTime = time - m_LastFrameTime;
		m_TimeStep = glm::min<float>(m_FrameTime, 0.0333f);
		m_LastFrameTime = time;
	}
	vkDeviceWaitIdle(m_Device.GetLogicalDevice());
}

void Application::Close()
{
	m_Running = false;
}

float Application::GetTime()
{
	return (float)glfwGetTime();
}

void Application::CreateImGuiDescriptorPool()
{
	VkDescriptorPoolSize pool_sizes[] =
	{
		{ VK_DESCRIPTOR_TYPE_SAMPLER,                1000 },
		{ VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 1000 },
		{ VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE,          1000 },
		{ VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,          1000 },
		{ VK_DESCRIPTOR_TYPE_UNIFORM_TEXEL_BUFFER,   1000 },
		{ VK_DESCRIPTOR_TYPE_STORAGE_TEXEL_BUFFER,   1000 },
		{ VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,         1000 },
		{ VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,         1000 },
		{ VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER_DYNAMIC, 1000 },
		{ VK_DESCRIPTOR_TYPE_STORAGE_BUFFER_DYNAMIC, 1000 },
		{ VK_DESCRIPTOR_TYPE_INPUT_ATTACHMENT,       1000 },
	};

	VkDescriptorPoolCreateInfo pool_info{};
	pool_info.sType         = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
	pool_info.flags         = VK_DESCRIPTOR_POOL_CREATE_FREE_DESCRIPTOR_SET_BIT;
	pool_info.maxSets       = 1000 * (uint32_t) std::size(pool_sizes);
	pool_info.poolSizeCount = (uint32_t)std::size(pool_sizes);
	pool_info.pPoolSizes    = pool_sizes;

	if (vkCreateDescriptorPool(m_Device.GetLogicalDevice(), &pool_info, nullptr, &m_ImGuiDescriptorPool) != VK_SUCCESS)
	{
		throw std::runtime_error("failed to create ImGui descriptor pool!");
	}
}

void Application::loadGameObjects()
{

}
