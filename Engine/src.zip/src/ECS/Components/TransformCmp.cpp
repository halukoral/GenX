#include "TransformCmp.h"

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/quaternion.hpp>

TransformCmp::TransformCmp(const STransformSpawnParams& params)
{
	Position = params.Position;
	Rotation = params.Rotation;
	Scale = params.Scale;
}

TransformCmp::TransformCmp(TransformCmp& other) : Component(other)
{
	Position = other.Position;
	Rotation = other.Rotation;
	Scale = other.Scale;

	WorldUp = other.WorldUp;

	Front = other.Front;
	Up = other.Up;
	Right = other.Right;
}

TransformCmp& TransformCmp::operator=(const TransformCmp& other)
{
	m_Entity = other.m_Entity;

	Position = other.Position;
	Rotation = other.Rotation;
	Scale = other.Scale;

	WorldUp = other.WorldUp;

	Front = other.Front;
	Up = other.Up;
	Right = other.Right;
	return *this;
}

glm::mat4 TransformCmp::GetTransform() const
{
	const glm::mat4 rotation = glm::toMat4(glm::quat(Rotation));
	return glm::translate(glm::mat4(1.0f), Position)
		* rotation
		* glm::scale(glm::mat4(1.0f), Scale);
}
