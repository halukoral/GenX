#pragma once
#include "pch.h"
#include "ECS/Component.h"

class TagCmp : public Component
{
public:
	COMPONENT_CLASS_TYPE(Tag)

	std::string Tag;

	TagCmp() = default;
	TagCmp(const TagCmp& other) : Component(other), Tag(other.Tag) {}
	TagCmp(const std::string& tag) : Tag(tag) {}

	TagCmp& operator=(const TagCmp& other)
	{
		m_Entity = other.m_Entity;

		Tag = other.Tag;
		return *this;
	}

};
