#include "Window.h"

#include "spdlog/spdlog.h"

void GlfwErrorCallback(int error, const char* description)
{
	spdlog::error ("Glfw Validation: {}", description);
}

Window::Window(uint32_t w, uint32_t h, std::string name): width(w), height(h), windowName(name)
{
	InitializeWindow();
}

Window::~Window()
{
	glfwDestroyWindow(window);
	glfwTerminate();
}

void Window::InitializeWindow()
{
	// Setup GLFW window
	glfwSetErrorCallback(GlfwErrorCallback);
	if (!glfwInit())
	{
		spdlog::error("Failed to initialize GLFW!");
		return;
	}
	glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);
	//glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
	window = glfwCreateWindow(width, height, windowName.c_str(), nullptr, nullptr);
}

void Window::CreateWindowSurface(const VkInstance instance, VkSurfaceKHR *surface) const
{
	if (glfwCreateWindowSurface(instance, window, nullptr, surface) != VK_SUCCESS)
	{
		throw std::runtime_error("failed to create window surface!");
	}
}

void Window::framebufferResizeCallback(GLFWwindow* window, int width, int height)
{
	auto window_ = reinterpret_cast<Window*>(glfwGetWindowUserPointer(window));
	window_->framebufferResized = true;
	window_->width = width;
	window_->height = height;
}
