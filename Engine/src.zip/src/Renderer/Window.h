#pragma once

#include "pch.h"
#define GLFW_INCLUDE_VULKAN
#include <GLFW/glfw3.h>

class Window
{
public:
	Window(uint32_t w, uint32_t h, std::string name);
	~Window();

	Window(const Window &) = delete;
	Window &operator=(const Window &) = delete;

	GLFWwindow* GetWindow() const { return window; }
	
	void InitializeWindow();

	bool ShouldClose() const { return glfwWindowShouldClose(window); }
	bool WasWindowResized() const { return framebufferResized; }
	void ResetWindowResizedFlag() { framebufferResized = false; }
	
	void CreateWindowSurface(VkInstance instance, VkSurfaceKHR *surface) const;

	int GetWidth() const { return width; }
	int GetHeight() const { return height; }

	VkExtent2D GetExtent() const
	{
		return {static_cast<uint32_t>(width), static_cast<uint32_t>(height)};
	}
	
private:
	static void framebufferResizeCallback(GLFWwindow *window, int width, int height);

private:
	int width;
	int height;
	bool framebufferResized = false;
	
	std::string windowName;
	GLFWwindow *window;  	
};
