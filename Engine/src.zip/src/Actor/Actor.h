#pragma once

class Actor
{
public:
	
};
